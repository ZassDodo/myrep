package pt.upacademy.jseproject.model;

public class Entity {
	
	private int ID;

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}
	

}
