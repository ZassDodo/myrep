package pt.upacademy.jseproject.repositories;

public class ProductRepository {

}
