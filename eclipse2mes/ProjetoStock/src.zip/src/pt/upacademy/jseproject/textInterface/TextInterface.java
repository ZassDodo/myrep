package pt.upacademy.jseproject.textInterface;

import java.util.ArrayList;
import java.util.HashMap;

import pt.upacademy.jseproject.model.Product;
import pt.upacademy.jseproject.model.Shelf;
import pt.upacademy.jseproject.utils.ScannerUtils;


public class TextInterface {

    static HashMap<Integer, Product> bdProd = new HashMap<Integer, Product>(); 
    static HashMap<Integer, Shelf> bdShelf = new HashMap<Integer, Shelf>(); 


	
	private static ScannerUtils sc = new ScannerUtils();

	public static void main(String[] args) {
		showMenuInitial();

	}

	private static void showMenuInitial() {
		
		int[] values = {1, 2, 3};
		while(true) {
			
			System.out.println("Por favor selecione uma das seguintes opções:");
			System.out.println("1) Listar produtos");
			System.out.println("2) Listar prateleiras");
			System.out.println("3) Sair");
			
			int result = sc.getInt("", values);
			System.out.println(result);
			
			switch(result) {
			case 1: showMenuProdutos();
			break;
			case 2: showMenuPrateleiras();
			break;
			case 3: System.exit(0);
			
			}
		}
	}
	
	private static void showMenuProdutos() {
		
		System.out.println("Por favor selecione uma das seguintes opções:");
		System.out.println("1) Criar novo produto");
		System.out.println("2) Editar um produto existente");
		System.out.println("3) Consultar o detalhe de um produto");
		System.out.println("4) Remover um produto");
		System.out.println("5) Voltar ao ecrã anterior");
		
		int[] values = {1, 2, 3, 4, 5};

		int result = sc.getInt("", values);
		System.out.println(result);


		switch(result) {
			case 1: criarProdutos();
			break;
			case 2: editProdutos();
			break;
			case 3: detProdutos();
			break;
			case 4: remProdutos();
			break;
			case 5: return;
		}
		
	}
	
	private static void criarProdutos() {
		int disc = sc.getInt("Escreva o IVA do produto");
		int iva = sc.getInt("Escreva o valor unitário de desconto");
		int pvp = sc.getInt("Escreva preço de venda ao público");

		Product prod = new Product(disc, iva ,pvp);
		prod.setID(1);
		bdProd.put(1, prod);
	}
	
	private static void editProdutos() {
		
		System.out.println("Ids existentes "+ bdProd.keySet());
		int id = sc.getInt("Escreva o id do produto que quer editar");
		//System.out.println(bdProd.get(id));
		Product productToEdit = bdProd.get(id);
		int disc = sc.getInt("Escreva o novo IVA do produto");
		int iva = sc.getInt("Escreva o novo valor unitário de desconto");
		int pvp = sc.getInt("Escreva o novo preço de venda ao público");
		System.out.println("Ids de prateleiras existentes "+ bdShelf.keySet());
		int shelfId = sc.getInt("Escreva o ID de uma nova prateleira para este produto");
		Shelf shelfToEdit = bdShelf.get(shelfId);
		productToEdit.setDisc(disc);
		productToEdit.setIva(iva);
		productToEdit.setPvp(pvp);
		
		
		bdProd.put(productToEdit.getID(), productToEdit);
		bdShelf.put(shelfToEdit.getID(), shelfToEdit);
		

		
	}

	
	private static void detProdutos() {
		System.out.println("O produto e " + bdProd.get(1));
	}
	
	private static void remProdutos() {
		
		
		
		
		System.out.println("O produto " + bdProd.remove(1) + " foi removido.");
		

			}
	
	
	
	
	private static void showMenuPrateleiras() {
		
		System.out.println("Por favor selecione uma das seguintes opções:");
		System.out.println("1) Criar nova prateleira");
		System.out.println("2) Editar uma prateleira existente");
		System.out.println("3) Consultar o detalhe de uma prateleira");
		System.out.println("4) Remover uma prateleira");
		System.out.println("5) Voltar ao ecrã anterior");
		
		int[] values = {1, 2, 3, 4, 5};

		int result = sc.getInt("", values);
		System.out.println(result);


		switch(result) {
			case 1: criarPrateleiras();
			break;
			case 2: editPrateleiras();
			break;
			case 3: detPrateleiras();
			break;
			case 4: remPrateleiras();
			break;
			case 5: return;
		}
	
}
	
	private static void criarPrateleiras() {
		
		int cap = sc.getInt("Escreva a capacidade da prateleira");
		System.out.println("Ids existentes "+ bdProd.keySet());
		int productId = sc.getInt("Escreva o produto que alberga");
		
		int pal = sc.getInt("Escreva o preço de aluguer de localização (diário)");


		Shelf shelf = new Shelf(cap, productId ,pal);
		shelf.setID(1);
		bdShelf.put(1, shelf);
		if(productId != 0) {
			Product prod = bdProd.get(productId);
			prod.addShelf(1);
		}
	}
	
	private static void editPrateleiras() {
		
		
		System.out.println("Ids existentes "+ bdShelf.keySet());
		int id = sc.getInt("Escreva o id da prateleira que quer editar");
		Shelf shelfToEdit = bdShelf.get(id);
		int cap = sc.getInt("Escreva a nova capacidade da prateleira");
		int productId = sc.getInt("Escreva o novo produto que alberga");
		int pal = sc.getInt("Escreva o novo preço de aluguer de localização (diário)");
		System.out.println("Ids de produtos existentes "+ bdProd.keySet());

		int prodId = sc.getInt("Escreva o ID de um produto para esta prateleira");
		Product productToEdit = bdProd.get(prodId);
		shelfToEdit.setCap(cap);
		shelfToEdit.setProductId(productId);
		shelfToEdit.setPal(pal);


		bdShelf.put(shelfToEdit.getID(), shelfToEdit);
		bdProd.put(productToEdit.getID(), productToEdit);

		
	}
	
	private static void detPrateleiras() {
		
		System.out.println("A prateleira e " + bdShelf.get(1));

	}
	
	private static void remPrateleiras() {
		
		System.out.println("Ids existentes "+ bdShelf.keySet());
		int id = sc.getInt("Escreva o id da prateleira que quer remover");
		Shelf removedShelf = bdShelf.remove(id);
		int productId = removedShelf.getProductId();
		if( productId != 0) {
			Product prod = bdProd.get(productId);
			prod.removeShelf(id);
			
		}
		System.out.println("A prateleira " + removedShelf + " foi removida.");
		


	}
	
}
