package pt.upacademy.jseproject.repositories;

public class ShelfRepository {

}
