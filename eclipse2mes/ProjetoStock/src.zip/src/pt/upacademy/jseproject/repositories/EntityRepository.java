package pt.upacademy.jseproject.repositories;

public class EntityRepository {

}
